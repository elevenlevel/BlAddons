class AddonAttribs():
    def __init__(self):
        self.info = "Test Info"

attributes = AddonAttribs()