from .additional import *
from .addon_data import *

def register():
    print(cl.text)

def unregister():
    pass

if __name__ == "__main__":
    register()