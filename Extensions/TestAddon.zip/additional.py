from .addon_data import *

class cl():
    text = attributes.info
    def __init__(self):
        print("additional hello")
        