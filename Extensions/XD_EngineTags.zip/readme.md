[![XDevs](https://xdevs.ltd/images/logo/xdevs.svg)](https://xdevs.ltd/)
## Описание
> Аддон для добавления квстомных свойств экспортируемым объектам

## Использование
```sh
• Панель аддона отображается в N панели.
• 
```

## Лицензия
XDevs Internal License