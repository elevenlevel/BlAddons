[![XDevs](https://xdevs.ltd/images/logo/xdevs.svg)](https://xdevs.ltd/)
## Описание
> Аддон для добавления атрибута "PrefabLink" на объект.

## Использование
```sh
• Панель аддона отображается в N панели.
• 
```

## Лицензия
XDevs Internal License